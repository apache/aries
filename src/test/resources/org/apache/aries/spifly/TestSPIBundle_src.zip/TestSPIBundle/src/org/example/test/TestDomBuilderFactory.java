package org.example.test;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class TestDomBuilderFactory extends DocumentBuilderFactory {
    @Override
    public Object getAttribute(String name) throws IllegalArgumentException {
        return null;
    }

    @Override
    public boolean getFeature(String name) throws ParserConfigurationException {
        return false;
    }

    @Override
    public DocumentBuilder newDocumentBuilder() throws ParserConfigurationException {
        throw new ParserConfigurationException("This one doesn't actually work");
    }

    @Override
    public void setAttribute(String name, Object value) throws IllegalArgumentException {}

    @Override
    public void setFeature(String name, boolean value) throws ParserConfigurationException {}
}
